package com.example.animation_container

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
